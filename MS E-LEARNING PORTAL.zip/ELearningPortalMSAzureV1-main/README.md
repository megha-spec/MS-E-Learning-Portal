# Online E Learning Portal Project Using MS Azure Cloud

All Database Scripts and DDLs are checked in to the Folder AllDatabaseTablesAndSPs

Please Refer the below link for demo:
https://youtu.be/ob4XInE7hVE

